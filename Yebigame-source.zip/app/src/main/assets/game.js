(function(){
'use strict';
// Retro art v4 (quality-audited): real image sprites, existing v2 save key and game rules.
const art=n=>'art/'+n+'.png';
const img=(n,cls='',alt='')=>`<img class="${cls}" src="${art(n)}" alt="${escapeHTML(alt)}" draggable="false">`;
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const SPECIES=[{id:'rabbit',name:'토끼',hello:'폴짝! 오늘도 신나요!'},{id:'cat',name:'고양이',hello:'냐옹! 같이 놀자!'},{id:'penguin',name:'펭귄',hello:'오늘은 어디로 갈까?'}];
const STATS=[{id:'love',name:'애정',icon:'♥',color:'#f4a0a6'},{id:'charm',name:'매력',icon:'★',color:'#ffda78'},{id:'brain',name:'지식',icon:'▣',color:'#94d8f2'},{id:'health',name:'건강',icon:'✚',color:'#a6d98b'}];
const ITEMS=[
{id:'snack',name:'작은 간식',stat:'love',gain:5,cost:16,origin:'shop'},
{id:'ribbon',name:'알록 리본',stat:'charm',gain:5,cost:16,origin:'shop'},
{id:'notebook',name:'작은 공책',stat:'brain',gain:5,cost:16,origin:'shop'},
{id:'carrot',name:'싱싱 당근',stat:'health',gain:5,cost:16,origin:'shop'},
{id:'bandage',name:'응급 붕대',heal:22,cost:24,origin:'shop'},
{id:'heartstone',name:'포근한 마음석',stat:'love',gain:18,origin:'dungeon'},
{id:'gem',name:'반짝 조약돌',stat:'charm',gain:18,origin:'dungeon'},
{id:'scroll',name:'낡은 지혜서',stat:'brain',gain:18,origin:'dungeon'},
{id:'herb',name:'힘찬 약초',stat:'health',gain:18,origin:'dungeon'},
{id:'rainbow',name:'무지개 열매',stat:'any',gain:26,origin:'dungeon'}];
const DECOR=[
{id:'flower',name:'꽃밭',sprite:'flowers',cost:0},
{id:'bench',name:'나무 의자',sprite:'bench',cost:90},
{id:'lantern',name:'작은 등불',sprite:'lantern',cost:105},
{id:'balloon',name:'풍선',sprite:'balloon',cost:125},
{id:'tree',name:'큰 나무',sprite:'apple_tree',cost:160}];
const ZONES=[
{id:'meadow',name:'풀숲 동굴',need:0,hp:16,attack:4,coin:14,icon:'mole',foes:['심술 두더지','통통 버섯','동굴 지킴이'],loot:['heartstone','herb'],sprites:['mole','mushroom_enemy','guardian']},
{id:'stream',name:'시냇물 유적',need:110,hp:30,attack:7,coin:24,icon:'slime',foes:['물방울 슬라임','조개 병정','유적 수호자'],loot:['gem','scroll'],sprites:['slime','shell_soldier','relic_golem']},
{id:'forest',name:'깊은 숲',need:350,hp:47,attack:11,coin:38,icon:'hedgehog',foes:['가시 도치','나뭇잎 정령','숲의 대장'],loot:['scroll','rainbow'],sprites:['hedgehog','leaf_spirit','forest_boss']}];
const SAVE_KEY='cozy-animal-farm-v2',OLD_KEY='cozy-animal-farm-v1';
const byId=(arr,id)=>arr.find(x=>x.id===id);
const clamp=(n,low,high)=>Math.max(low,Math.min(high,Math.floor(Number(n)||0)));
const freshStats=()=>({love:0,charm:0,brain:0,health:0});
const random=a=>a[Math.floor(Math.random()*a.length)];
function initial(){return {version:2,started:false,current:'rabbit',unlocked:[],finished:[],coins:80,owned:['flower'],equipped:['flower'],pets:{rabbit:freshStats(),cat:freshStats(),penguin:freshStats()},bag:{snack:2,ribbon:1,notebook:1,carrot:2,bandage:2},dungeon:null,clears:{meadow:0,stream:0,forest:0},totalRuns:0};}
function load(){
 const out=initial();let source=null,legacy=false;
 try{source=JSON.parse(localStorage.getItem(SAVE_KEY));}catch(e){}
 if(!source){try{source=JSON.parse(localStorage.getItem(OLD_KEY));legacy=!!source;}catch(e){}}
 if(!source||typeof source!=='object')return out;
 out.started=!!source.started;
 if(byId(SPECIES,source.current))out.current=source.current;
 out.coins=clamp(source.coins,0,100000000);
 for(const key of ['unlocked','finished']) if(Array.isArray(source[key]))out[key]=[...new Set(source[key].filter(id=>byId(SPECIES,id)))];
 for(const key of ['owned','equipped']) if(Array.isArray(source[key]))out[key]=[...new Set(source[key].filter(id=>byId(DECOR,id)))];
 if(!out.owned.includes('flower'))out.owned.push('flower');
 out.equipped=out.equipped.filter(id=>out.owned.includes(id));
 SPECIES.forEach(s=>STATS.forEach(st=>out.pets[s.id][st.id]=clamp(source.pets?.[s.id]?.[st.id],0,300)));
 if(out.started&&!out.unlocked.includes(out.current))out.unlocked.push(out.current);
 if(!legacy){
  if(source.bag&&typeof source.bag==='object'){out.bag={};ITEMS.forEach(i=>out.bag[i.id]=clamp(source.bag[i.id],0,999));}
  if(source.clears&&typeof source.clears==='object')ZONES.forEach(z=>out.clears[z.id]=clamp(source.clears[z.id],0,999999));
  out.totalRuns=clamp(source.totalRuns,0,999999);
  const d=source.dungeon;
  if(d&&byId(ZONES,d.zone)&&d.room>=1&&d.room<=3&&byId(SPECIES,d.pet))out.dungeon={zone:d.zone,pet:d.pet,room:clamp(d.room,1,3),hp:clamp(d.hp,1,999),maxHp:clamp(d.maxHp,1,999),enemyHp:clamp(d.enemyHp,1,999),earned:clamp(d.earned,0,100000),found:Array.isArray(d.found)?d.found.filter(i=>byId(ITEMS,i)).slice(0,15):[],log:String(d.log||'탐험을 이어가자!').slice(0,150)};
 }
 return out;
}
const state=load();let tab='farm',modal=null,flavor='',flavorId='',petImageOverride='',petMotion=false,fightFx='',toastTimer=null;
function save(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(state));}catch(e){}}
if(state.started)save();
const petStats=id=>state.pets[id];
const total=id=>STATS.reduce((n,s)=>n+petStats(id)[s.id],0);
const avg=id=>Math.floor(total(id)/4);
const tier=id=>avg(id)>=210?2:avg(id)>=95?1:0;
const stage=id=>['기본형','1차 성장','2차 성장'][tier(id)];
const allDone=id=>STATS.every(s=>petStats(id)[s.id]>=300);
const petName=id=>(byId(SPECIES,id)||SPECIES[0]).name;
const count=id=>state.bag[id]||0;
const wallet=()=>state.coins.toLocaleString('ko-KR');
const maxHP=id=>48+Math.floor(petStats(id).health/10);
const attackPower=id=>9+Math.floor(petStats(id).brain/35)+Math.floor(petStats(id).charm/70);
const foeHP=(z,room)=>z.hp+(room-1)*8;
const foeAttack=(z,room)=>z.attack+(room-1)*2;
function animalSrc(id,kind=''){return art(id+'_'+(kind||tier(id)));}
function header(){return `<div class="brand">${img('logo_title','logo-title','포근동물농장')}</div><header class="topbar">${img(state.current+'_0','avatar',petName(state.current))}<div class="top-info"><small>${petName(state.current)} · ${state.finished.length}/3 엔딩</small><div class="small-meter"><div style="width:${Math.max(3,avg(state.current)/3)}%;background:#ffda78"></div></div></div><div class="money">${img('coin','','코인')}<span>${wallet()}</span></div></header>`;}
function nav(){return `<nav class="nav" aria-label="게임 메뉴">${[['farm','농장'],['dungeon','던전'],['bag','가방'],['shop','상점'],['book','도감']].map(([id,label])=>`<button type="button" data-a="tab" data-id="${id}" aria-label="${label}" aria-current="${tab===id?'page':'false'}">${img('nav_'+id+(tab===id?'_active':''),'',label)}</button>`).join('')}</nav>`;}
function statsPanel(id){return `<div class="stats">${STATS.map(s=>`<div class="card stat"><div class="stat-head"><strong><span class="stat-symbol" style="color:${s.color}">${s.icon}</span>${s.name}</strong><span>${petStats(id)[s.id]}/300</span></div><div class="meter"><div style="width:${petStats(id)[s.id]/3}%;background:${s.color}"></div></div></div>`).join('')}</div>`;}
function welcome(){return `<section class="intro"><div class="chip">🐾 처음 만나는 작은 친구</div><h1>포근동물농장에 어서 와!</h1><p class="sub">아이템을 모아 동물을 키우고, 던전에서 모험하자.</p><div class="section-head">첫 번째 친구 선택</div><div class="starter-list">${SPECIES.map(s=>`<button class="card starter" data-a="starter" data-id="${s.id}">${img(s.id+'_0','',s.name)}<strong>${s.name}</strong><small>이 친구와 시작</small></button>`).join('')}</div><p class="footnote">플레이 진행은 이 휴대폰에 자동 저장돼.</p></section>`;}
function farm(){let id=state.current,s=byId(SPECIES,id);let decor=state.equipped.filter(d=>d!=='flower').map(d=>byId(DECOR,d)).filter(Boolean).slice(0,2).map((d,i)=>img(d.sprite,'prop '+(i===0?'hay':'flowers'),d.name)).join('');
 return `<div class="chip">🐾 ${['새싹 농부','다정한 사육사','행복한 농장주','전설의 친구'][Math.min(3,state.finished.length)]} · 성장 엔딩 ${state.finished.length}/3</div><h1>오늘의 농장</h1><p class="sub">${s.name}와 함께하는 평화로운 하루</p>
 <div class="farm-scene">${img('farm_scene','landscape','농장 배경')}${img('barn','prop barn','헛간')}${img('windmill','prop windmill','풍차')}${img('carrot_crate','prop carrot_crate','당근 상자')}${decor}<div class="bubble" id="pet-message">${escapeHTML(flavorId===id&&flavor?flavor:s.hello)}</div><button class="animal ${petMotion?'hop':''}" type="button" data-a="pet" aria-label="${s.name} 쓰다듬기"><img src="${petImageOverride&&flavorId===id?art(petImageOverride):animalSrc(id)}" alt="${s.name} ${stage(id)}"></button><span class="stage">${stage(id)}</span></div>
 <div class="identity"><div><strong>${s.name}</strong><small>평균 능력치 ${avg(id)} / 300</small></div><span class="flag">${allDone(id)?'성장 완료':'성장 중'}</span></div><div class="section-head">능력치<small>아이템으로 성장!</small></div>${statsPanel(id)}<div class="tip"><strong>돈만 써서는 성장할 수 없어!</strong> 상점에서 아이템을 구하거나 던전에서 희귀 아이템을 획득한 뒤 가방에서 사용하자.</div><div class="actions"><button class="btn yellow" data-a="tab" data-id="bag">🎒 아이템 사용</button><button class="btn green" data-a="tab" data-id="dungeon">⚔ 던전 탐험</button></div>`;}
function itemDescription(item){if(item.heal)return '전투 중 체력 +'+item.heal;let s=byId(STATS,item.stat);return (s?s.name:'선택 능력치')+' +'+item.gain;}
function inventory(){return `<div class="chip">🎁 아이템을 사용할수록 성장!</div><h1>내 가방</h1><p class="sub">육성 대상: <strong>${petName(state.current)}</strong> · ${stage(state.current)} / 상점 아이템 +5, 던전 아이템 +18~26</p><div class="section-head">육성 아이템</div><div class="grid-list">${ITEMS.map(i=>`<div class="card inventory-item"><div class="item-icon">${img(i.id,'',i.name)}</div><div class="item-body"><strong>${i.name}</strong><small>${itemDescription(i)} · ${i.origin==='shop'?'상점':'던전'}</small><b>보유 ${count(i.id)}개</b></div><button class="mini-btn" data-a="use" data-id="${i.id}" ${!i.stat||!count(i.id)?'disabled':''}>${i.heal?'전투용':!count(i.id)?'없음':'사용'}</button></div>`).join('')}</div><p class="footnote">전투용 붕대는 던전 화면에서 사용할 수 있어.</p>`;}
function shop(){return `<div class="chip">🛍 작은 성장, 확실한 준비</div><h1>마을 상점</h1><p class="sub">상점 아이템은 능력치가 조금만 올라가. 강력한 아이템은 던전에서 구할 수 있어.</p><div class="section-head">아이템 구매</div><div class="grid-list">${ITEMS.filter(i=>i.cost).map(i=>`<div class="card inventory-item"><div class="item-icon">${img(i.id,'',i.name)}</div><div class="item-body"><strong>${i.name}</strong><small>${itemDescription(i)}</small><b>보유 ${count(i.id)}개</b></div><button class="mini-btn" data-a="buy" data-id="${i.id}" ${state.coins<i.cost?'disabled':''}>🪙 ${i.cost}</button></div>`).join('')}</div><div class="section-head">농장 장식</div><div class="decor-grid">${DECOR.map(d=>{let own=state.owned.includes(d.id),on=state.equipped.includes(d.id);return `<div class="card decor-card">${img(d.sprite,'',d.name)}<strong>${d.name}</strong><button class="mini-btn" data-a="decor" data-id="${d.id}" ${!own&&state.coins<d.cost?'disabled':''}>${own?(on?'치우기':'배치하기'):'🪙 '+d.cost}</button></div>`}).join('')}</div>`;}
function dungeon(){let r=state.dungeon;if(!r){return `<div class="chip">⚔ 싸워서 코인과 아이템 획득!</div><h1>던전 탐험</h1><p class="sub">3번의 전투로 한 구역을 클리어. 패배해도 획득한 아이템은 유지돼.</p><div class="tip">참가 동물 <strong>${petName(state.current)}</strong> · 공격력 ${attackPower(state.current)} · 체력 ${maxHP(state.current)}<br>더 어려운 던전은 능력치 합계가 높아야 입장 가능.</div><div class="grid-list">${ZONES.map(z=>{let ok=total(state.current)>=z.need;return `<div class="card zone-entry"><div class="zone-icon">${img(z.icon,'',z.name)}</div><div class="zone-body"><strong>${z.name}</strong><small>${ok?'입장 가능':`능력치 합계 ${z.need} 필요`} · 완료 ${state.clears[z.id]}회</small><small>3번의 전투 · 코인 + 희귀 아이템</small></div><button class="mini-btn" data-a="enter" data-id="${z.id}" ${ok?'':'disabled'}>${ok?'입장':'잠김'}</button></div>`}).join('')}</div>`;}
 let z=byId(ZONES,r.zone),foe=z.foes[r.room-1],sprite=z.sprites[r.room-1],hpTotal=foeHP(z,r.room);
 return `<div class="chip">⚔ ${z.name} · ${r.room}/3 전투</div><h1>던전 전투</h1><p class="sub">참가: ${petName(r.pet)} · 획득 코인 ${r.earned} · 획득 아이템 ${r.found.length}개</p><div class="card battle"><div class="battle-field">${img(sprite+(fightFx==='jump'&&sprite==='slime'?'_jump':''),'enemy '+(fightFx==='hit'?'hit':fightFx==='attack'?'attack':''),foe)}</div><div class="enemy-name">${foe}</div><div class="meters"><div><div class="battle-row"><strong>몬스터 HP</strong><span>${r.enemyHp}/${hpTotal}</span></div><div class="meter"><div style="width:${100*r.enemyHp/hpTotal}%;background:#ee9495"></div></div></div><div><div class="battle-row"><strong>${petName(r.pet)} HP</strong><span>${r.hp}/${r.maxHp}</span></div><div class="meter"><div style="width:${100*r.hp/r.maxHp}%;background:#9ed886"></div></div></div></div><div class="battle-log">${escapeHTML(r.log)}</div><div class="battle-actions"><button class="btn" data-a="fight" data-id="attack">⚔ 공격</button><button class="btn blue" data-a="fight" data-id="guard">🛡 방어</button><button class="btn yellow" data-a="heal" ${!count('bandage')||r.hp>=r.maxHp?'disabled':''}>🩹 붕대 (${count('bandage')})</button><button class="btn white" data-a="leave">🚪 후퇴</button></div></div>`;}
function book(){return `<div class="chip">📖 우리 동물 친구들</div><h1>동물 도감</h1><p class="sub">네 능력치 모두 300을 달성하면 다음 친구가 열려!</p><div class="grid-list">${SPECIES.map(s=>{let has=state.unlocked.includes(s.id),finished=state.finished.includes(s.id);return `<div class="card pet-entry">${img(s.id+'_'+(has?tier(s.id):0),'pet-avatar',s.name)}<div class="pet-body"><strong>${s.name} ${has?'':'🔒'}</strong><small>${has?'성장 단계 '+stage(s.id):'앞선 동물의 성장 엔딩을 완료해줘'}</small><small>${finished?'🏆 성장 엔딩 달성!':has?'능력치 합계 '+total(s.id)+'/1200':'아직 잠겨있어'}</small></div><button class="mini-btn" data-a="select" data-id="${s.id}" ${!has?'disabled':''}>${state.current===s.id?'선택 중':'선택'}</button></div>`}).join('')}</div><div class="tip">현재 엔딩 ${state.finished.length}/3 · 완료한 던전 ${ZONES.reduce((n,z)=>n+state.clears[z.id],0)}회</div>`;}
function modalHTML(){if(!modal)return '';const buttons=modal.buttons||[{label:'확인',action:'modal-close'}];return `<div class="modal-wrap" role="dialog" aria-modal="true" aria-label="${escapeHTML(modal.title)}"><div class="modal"><div class="medal">${modal.icon||'🐾'}</div><h2>${escapeHTML(modal.title)}</h2><p>${escapeHTML(modal.body)}</p><div class="actions">${buttons.map(b=>`<button class="btn ${b.color||'yellow'}" data-a="${b.action}" ${b.id?`data-id="${b.id}"`:''}>${escapeHTML(b.label)}</button>`).join('')}</div></div></div>`;}
function render(){let root=document.getElementById('root');if(!root)return;root.innerHTML=header()+(state.started?({farm,dungeon,bag:inventory,shop,book})[tab]():welcome())+(state.started?nav():'')+modalHTML();}
function toast(message){const e=document.getElementById('toast');if(!e)return;e.textContent=message;e.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>e.hidden=true,2200);}
function chooseStarter(id){if(state.started||!byId(SPECIES,id))return;state.started=true;state.current=id;state.unlocked=[id];save();render();}
function petTouch(){if(!state.started)return;const s=byId(SPECIES,state.current);flavorId=s.id;flavor=random([s.hello,'만나서 반가워!','오늘도 좋은 하루야!','쓰다듬어줘서 고마워!']);petImageOverride=tier(s.id)>=2?s.id+'_idle_b':'';petMotion=true;const root=document.getElementById('root'),b=root?.querySelector('.animal');if(b)b.classList.add('hop');render();setTimeout(()=>{petImageOverride='';petMotion=false;flavor='';render();},750);}
function afterGrow(id){if(!allDone(id)||state.finished.includes(id))return;state.finished.push(id);const index=SPECIES.findIndex(x=>x.id===id),next=SPECIES[index+1];if(next&&!state.unlocked.includes(next.id))state.unlocked.push(next.id);modal={icon:'🏆',title:petName(id)+' 성장 완료!',body:next?next.name+' 친구가 새로 열렸어! 도감에서 선택해 봐.':'모든 동물을 성장시켰어! 축하해!',buttons:[{label:'좋아!',action:'modal-close'}]};}
function applyItem(item,stat){if(!item||!count(item.id)||!byId(STATS,stat))return;let target=petStats(state.current);if(target[stat]>=300){toast('이미 최대 능력치야!');return;}state.bag[item.id]--;target[stat]=clamp(target[stat]+item.gain,0,300);afterGrow(state.current);save();render();toast(item.name+' 사용! '+byId(STATS,stat).name+' +'+item.gain);}
function useItem(id){let item=byId(ITEMS,id);if(!item||!count(id)||!item.stat)return;if(item.stat==='any'){modal={icon:'🌈',title:'무지개 열매 사용',body:'올리고 싶은 능력치를 골라줘.',buttons:STATS.map(s=>({label:s.icon+' '+s.name,action:'rainbow',id:s.id,color:'white'}))};render();return;}applyItem(item,item.stat);}
function buyItem(id){let item=byId(ITEMS,id);if(!item||!item.cost||state.coins<item.cost){toast('코인이 부족해!');return;}state.coins-=item.cost;state.bag[id]=count(id)+1;save();render();toast(item.name+' 1개 구매! 가방에서 사용할 수 있어.');}
function buyDecor(id){const d=byId(DECOR,id);if(!d)return;let own=state.owned.includes(id),on=state.equipped.includes(id);if(!own){if(state.coins<d.cost){toast('코인이 부족해!');return;}state.coins-=d.cost;state.owned.push(id);state.equipped.push(id);}else if(on)state.equipped=state.equipped.filter(i=>i!==id);else state.equipped.push(id);save();render();}
function selectPet(id){if(!state.unlocked.includes(id))return;state.current=id;save();tab='farm';render();}
function enterDungeon(id){const z=byId(ZONES,id);if(state.dungeon||!z||total(state.current)<z.need)return;state.dungeon={zone:id,room:1,hp:maxHP(state.current),maxHp:maxHP(state.current),enemyHp:foeHP(z,1),earned:0,found:[],log:z.foes[0]+' 등장! 공격하거나 방어해 보자.',pet:state.current};state.totalRuns++;save();render();}
function winRoom(){const r=state.dungeon;if(!r)return;const z=byId(ZONES,r.zone),room=r.room;const coin=z.coin+(room-1)*7+Math.floor(Math.random()*7);const loot=room===3&&Math.random()<.3?'rainbow':random(z.loot);state.coins+=coin;state.bag[loot]=count(loot)+1;r.earned+=coin;r.found.push(loot);fightFx='';if(room===3){state.clears[z.id]++;const earned=r.earned,found=r.found.map(id=>byId(ITEMS,id).name).join(', ');state.dungeon=null;modal={icon:'🏆',title:z.name+' 돌파 성공!',body:'코인 '+earned+'개 획득!\n아이템: '+found+'\n가방에서 사용해 동물을 성장시키자.'};save();render();return;}r.room++;r.enemyHp=foeHP(z,r.room);r.log='승리! 🪙 '+coin+'개와 '+byId(ITEMS,loot).name+' 획득. 다음 적이 등장했어.';save();render();}
function fight(action){const r=state.dungeon;if(!r||!['attack','guard'].includes(action))return;const z=byId(ZONES,r.zone);let damage=action==='attack'?attackPower(r.pet)+Math.floor(Math.random()*4):3;r.enemyHp=Math.max(0,r.enemyHp-damage);if(!r.enemyHp){winRoom();return;}const counter=Math.max(1,foeAttack(z,r.room)+Math.floor(Math.random()*3)-(action==='guard'?Math.ceil(foeAttack(z,r.room)*.8):0));r.hp=Math.max(0,r.hp-counter);r.log=(action==='guard'?'방어 성공! ':'공격 성공! ')+'적에게 '+damage+' 피해, 반격으로 '+counter+' 피해.';if(r.hp<=0){const earned=r.earned;state.dungeon=null;modal={icon:'💤',title:'던전에서 쓰러졌어',body:'이번에 얻은 코인 '+earned+'개와 아이템은 그대로 가지고 있어. 다시 도전하자!'};}save();fightFx='hit';render();setTimeout(()=>{fightFx='';if(state.dungeon)render();},320);}
function healBattle(){const r=state.dungeon;if(!r)return;if(!count('bandage'))return toast('붕대가 없어!');if(r.hp>=r.maxHp)return toast('이미 체력이 가득해!');state.bag.bandage--;let n=Math.min(22,r.maxHp-r.hp);r.hp+=n;r.log='붕대로 체력 '+n+' 회복! (적 반격 없음)';save();render();}
function leaveDungeon(){const r=state.dungeon;if(!r)return;const earned=r.earned;state.dungeon=null;save();render();toast('후퇴! 코인 '+earned+'개와 획득 아이템 유지.');}
function switchTab(id){if(!['farm','dungeon','bag','shop','book'].includes(id))return;tab=id;flavor='';petImageOverride='';render();window.scrollTo?.(0,0);}
function closeModal(){modal=null;render();}
document.addEventListener('click',function(e){const el=e.target.closest('button[data-a]');if(!el||el.disabled)return;let a=el.dataset.a,id=el.dataset.id;
 switch(a){case 'starter':chooseStarter(id);break;case 'pet':petTouch();break;case 'tab':switchTab(id);break;case 'use':useItem(id);break;case 'buy':buyItem(id);break;case 'decor':buyDecor(id);break;case 'select':selectPet(id);break;case 'enter':enterDungeon(id);break;case 'fight':fight(id);break;case 'heal':healBattle();break;case 'leave':leaveDungeon();break;case 'rainbow':modal=null;applyItem(byId(ITEMS,'rainbow'),id);break;case 'modal-close':closeModal();break;}
});
window.gameBack=function(){if(modal){closeModal();return true;}if(tab!=='farm'){switchTab('farm');return true;}return false;};
window.__retroGame={state,SPECIES,STATS,ITEMS,ZONES,chooseStarter,selectPet,buyItem,useItem,enterDungeon,fight,healBattle,leaveDungeon,render,switchTab};
render();
})();
