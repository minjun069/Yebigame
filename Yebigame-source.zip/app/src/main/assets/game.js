(function () {
'use strict';
const SPECIES = [
  {id:'rabbit', name:'토끼', hello:'폴짝! 오늘도 신나요!'},
  {id:'cat', name:'고양이', hello:'냐옹! 쓰다듬어 줘!'},
  {id:'penguin', name:'펭귄', hello:'같이 놀러 갈래?'}
];
const STATS = [
  {id:'love', name:'애정', emoji:'💗', color:'#f4a0b3'},
  {id:'charm', name:'매력', emoji:'✨', color:'#e3b66b'},
  {id:'brain', name:'지식', emoji:'📖', color:'#a0b7ea'},
  {id:'health', name:'건강', emoji:'🍀', color:'#85ccaa'}
];
const CARE = [
  {id:'play', name:'놀아주기', emoji:'🧸', cost:0, stat:'love', gain:25},
  {id:'dress', name:'꾸며주기', emoji:'🎀', cost:8, stat:'charm', gain:25},
  {id:'study', name:'공부하기', emoji:'📚', cost:6, stat:'brain', gain:25},
  {id:'feed', name:'밥 먹이기', emoji:'🥕', cost:7, stat:'health', gain:25}
];
const SHOP = [
  {id:'flower', name:'꽃밭', emoji:'🌷', cost:0, detail:'꽃향기 가득한 농장'},
  {id:'bench', name:'나무 의자', emoji:'🪑', cost:70, detail:'동물의 쉼터'},
  {id:'lantern', name:'작은 등불', emoji:'🏮', cost:95, detail:'포근한 밤 풍경'},
  {id:'balloon', name:'풍선', emoji:'🎈', cost:105, detail:'둥실둥실 축제'},
  {id:'tree', name:'큰 나무', emoji:'🌳', cost:140, detail:'시원한 그늘'}
];
const KEY='cozy-animal-farm-v1';
const freshPet=()=>({love:0,charm:0,brain:0,health:0});
function initial(){return {started:false,current:'rabbit',unlocked:[],finished:[],coins:130,owned:['flower'],equipped:['flower'],pets:{rabbit:freshPet(),cat:freshPet(),penguin:freshPet()},best:0};}
function load(){
  const s=initial();
  try {
    const raw=JSON.parse(localStorage.getItem(KEY));
    if(!raw || typeof raw!=='object')return s;
    s.started=!!raw.started;
    s.current=SPECIES.some(x=>x.id===raw.current)?raw.current:'rabbit';
    s.coins=Number.isFinite(raw.coins)?Math.max(0,Math.floor(raw.coins)):130;
    s.best=Number.isFinite(raw.best)?Math.max(0,Math.floor(raw.best)):0;
    for(const key of ['unlocked','finished'])if(Array.isArray(raw[key]))s[key]=raw[key].filter(id=>SPECIES.some(x=>x.id===id));
    for(const key of ['owned','equipped'])if(Array.isArray(raw[key]))s[key]=raw[key].filter(id=>SHOP.some(x=>x.id===id));
    for(const kind of SPECIES){
      const old=raw.pets&&raw.pets[kind.id]||{};
      for(const st of STATS){const value=old[st.id];s.pets[kind.id][st.id]=Number.isFinite(value)?Math.min(300,Math.max(0,Math.floor(value))):0;}
    }
    if(s.started && !s.unlocked.includes(s.current))s.unlocked.push(s.current);
    if(!s.owned.includes('flower'))s.owned.push('flower');
    s.equipped=s.equipped.filter(x=>s.owned.includes(x));
  }catch(e){/* 저장소를 사용할 수 없어도 게임은 계속 진행 */}
  return s;
}
const state=load();
let tab='farm', modal=null, lastTap=0, toastTimer=null;
const mini={active:false,score:0,time:20,spawnTimer:null,clockTimer:null};
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){}};
const species=id=>SPECIES.find(x=>x.id===id);
const avg=id=>Math.floor(STATS.reduce((sum,x)=>sum+state.pets[id][x.id],0)/4);
const allDone=id=>STATS.every(x=>state.pets[id][x.id]>=300);
const stage=id=>avg(id)>=300?'반짝반짝 어른':avg(id)>=180?'씩씩한 친구':avg(id)>=90?'쑥쑥 어린이':'꼬마 친구';
const rank=()=>['새싹 농부','다정한 사육사','행복한 농장주','전설의 동물 친구'][Math.min(3,state.finished.length)];
function animalSvg(id){
  let body='',head='',orn='';
  if(id==='rabbit'){
    body='<ellipse cx="120" cy="189" rx="68" ry="47" fill="#fffdfb"/><ellipse cx="85" cy="220" rx="19" ry="11" fill="#f9eef2"/><ellipse cx="155" cy="220" rx="19" ry="11" fill="#f9eef2"/>';
    head='<ellipse cx="86" cy="52" rx="18" ry="52" transform="rotate(-13 86 52)" fill="#fffdfb"/><ellipse cx="154" cy="52" rx="18" ry="52" transform="rotate(13 154 52)" fill="#fffdfb"/><ellipse cx="86" cy="51" rx="8" ry="37" transform="rotate(-13 86 51)" fill="#f7c5d1"/><ellipse cx="154" cy="51" rx="8" ry="37" transform="rotate(13 154 51)" fill="#f7c5d1"/><ellipse cx="120" cy="131" rx="71" ry="68" fill="#fffdfb"/><ellipse cx="91" cy="146" rx="12" ry="8" fill="#ffdce5"/><ellipse cx="149" cy="146" rx="12" ry="8" fill="#ffdce5"/><ellipse cx="98" cy="127" rx="5.5" ry="7.5" fill="#504359"/><ellipse cx="142" cy="127" rx="5.5" ry="7.5" fill="#504359"/><path d="M115 146 Q120 140 125 146 Q123 151 120 152Z" fill="#e58fa2"/><path d="M120 152q-7 9-14 0m14 0q7 9 14 0" fill="none" stroke="#c88b9d" stroke-width="2.2" stroke-linecap="round"/>';
  } else if(id==='cat'){
    body='<ellipse cx="122" cy="189" rx="65" ry="48" fill="#f5c99a"/><path d="M174 200 Q223 208 203 151" fill="none" stroke="#f5c99a" stroke-width="19" stroke-linecap="round"/><ellipse cx="90" cy="222" rx="17" ry="10" fill="#ffdfb9"/><ellipse cx="151" cy="222" rx="17" ry="10" fill="#ffdfb9"/>';
    head='<path d="M55 103 L64 37 Q69 25 81 37 L108 58 Q120 54 132 58 L161 36 Q174 26 177 41 L185 103 Q202 161 167 173 Q120 191 73 173 Q37 154 55 103Z" fill="#f5c99a"/><path d="M66 49L82 73 67 85Z M174 49L157 73 173 85Z" fill="#f3aeb0"/><ellipse cx="87" cy="141" rx="13" ry="8" fill="#f8d7bf"/><ellipse cx="153" cy="141" rx="13" ry="8" fill="#f8d7bf"/><ellipse cx="98" cy="123" rx="5.5" ry="7" fill="#504359"/><ellipse cx="142" cy="123" rx="5.5" ry="7" fill="#504359"/><path d="M115 140L125 140 120 146Z" fill="#cf8d8c"/><path d="M120 146q-8 10-14 1m14-1q8 10 14 1" fill="none" stroke="#8a706d" stroke-width="2" stroke-linecap="round"/><path d="M67 143l-18 -4m18 13l-18 3m124 -12l18 -4m-18 13l18 3" stroke="#9d7969" stroke-width="2" stroke-linecap="round"/>';
  } else {
    body='<ellipse cx="120" cy="157" rx="76" ry="82" fill="#47546b"/><ellipse cx="120" cy="165" rx="50" ry="66" fill="#fff8ed"/><ellipse cx="60" cy="176" rx="20" ry="51" transform="rotate(18 60 176)" fill="#48556a"/><ellipse cx="180" cy="176" rx="20" ry="51" transform="rotate(-18 180 176)" fill="#48556a"/><ellipse cx="95" cy="226" rx="24" ry="10" fill="#ffc56d"/><ellipse cx="146" cy="226" rx="24" ry="10" fill="#ffc56d"/>';
    head='<ellipse cx="120" cy="94" rx="65" ry="66" fill="#47546b"/><ellipse cx="98" cy="102" rx="27" ry="42" fill="#fff9f2"/><ellipse cx="142" cy="102" rx="27" ry="42" fill="#fff9f2"/><circle cx="99" cy="107" r="6" fill="#4b4258"/><circle cx="141" cy="107" r="6" fill="#4b4258"/><ellipse cx="91" cy="125" rx="10" ry="7" fill="#f8c6cb"/><ellipse cx="150" cy="125" rx="10" ry="7" fill="#f8c6cb"/><path d="M109 128 Q120 119 131 128 L120 142Z" fill="#ffbd65"/>';
  }
  if(avg(id)>=90)orn='<path d="M82 171q38 15 76 0l-14 16q-24 9-49 0z" fill="#f7a4b5"/><circle cx="120" cy="184" r="7" fill="#fff2ad"/>';
  if(avg(id)>=180)orn+='<path d="M104 54L112 34 120 49 130 31 137 52 146 45 146 60 104 60Z" fill="#ffd16e" stroke="#e5a24a" stroke-width="2"/>';
  return '<svg viewBox="0 0 240 240" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'+body+head+orn+'</svg>';
}
function header(){return '<div class="topbar"><div class="brand"><div class="logo">🐾</div><div><small>COZY ANIMAL FARM</small><strong>포근동물농장</strong></div></div><div class="wallet"><span>🪙</span><span>'+state.coins.toLocaleString('ko-KR')+'</span></div></div>';}
function nav(){return '<nav class="nav" aria-label="게임 메뉴">'+[['farm','🏡','농장'],['play','⭐','놀이터'],['shop','🛍️','상점'],['book','📒','도감']].map(x=>'<button class="'+(tab===x[0]?'active':'')+'" onclick="switchTab(\''+x[0]+'\')"><b>'+x[1]+'</b>'+x[2]+'</button>').join('')+'</nav>';}
function welcome(){return '<div class="welcome"><div class="welcome-chip">🌼 너만의 작은 농장이 기다려!</div><span class="mascot">🏡🐾</span><h1 class="section-title" style="font-size:30px">포근동물농장에<br>어서 와!</h1><p class="sub">작은 동물과 친구가 되어 보자.<br>매일 돌보고, 놀고, 함께 성장하는 농장 이야기</p><div class="hero-lite" style="text-align:left"><h2>첫 번째 친구를 골라 줘 🐣</h2><p>어떤 동물을 골라도 좋아!<br>다 키우면 다른 친구들도 만나게 돼.</p></div><div class="select-list">'+SPECIES.map(s=>'<button class="select-btn" onclick="chooseStarter(\''+s.id+'\')">'+animalSvg(s.id)+'<strong>'+s.name+'</strong><small>함께 시작하기</small></button>').join('')+'</div><p class="note">💾 진행 상황은 자동으로 저장돼.<br>인터넷 연결 없이도 즐길 수 있어!</p></div>';}
function farm(){
  const p=state.pets[state.current],s=species(state.current);
  const decor=state.equipped.map(id=>{const item=SHOP.find(x=>x.id===id);return item?'<span class="deco '+id+'">'+item.emoji+'</span>':'';}).join('');
  const stats=STATS.map(x=>'<div class="stat"><div class="stat-head"><span>'+x.emoji+' '+x.name+'</span><em>'+p[x.id]+'/300</em></div><div class="track"><div class="fill" style="width:'+(p[x.id]/3)+'%;background:'+x.color+'"></div></div></div>').join('');
  const care=CARE.map(x=>'<button class="care" onclick="doCare(\''+x.id+'\')"><span class="emoji">'+x.emoji+'</span><strong>'+x.name+'</strong><small>'+(x.cost?'🪙 '+x.cost:'무료')+'</small></button>').join('');
  return '<div class="welcome-chip">🏅 '+rank()+' · 엔딩 '+state.finished.length+'/3</div><h1 class="section-title">오늘도 행복한 농장 🌷</h1><p class="sub">동물을 터치해 인사하고, 정성껏 키워 줘!</p><div class="sky"><span class="sun"></span><span class="cloud"></span><span class="cloud two"></span><span class="hill"></span><span class="hill right"></span><span class="ground"></span><span class="grass left">🌱 ✿ 🌱</span><span class="grass right">🌿 🌼</span>'+decor+'<div class="bubble">'+s.hello+'</div><button class="pet" aria-label="'+s.name+' 쓰다듬기" onclick="petTouch()">'+animalSvg(s.id)+'</button><div class="stage-chip">🌟 '+stage(s.id)+'</div></div><div class="name-strip"><div><div class="pet-name">'+s.name+'와 나의 농장</div><div class="pet-detail">성장 포인트 '+avg(s.id)+' / 300</div></div><span class="tag">'+(allDone(s.id)?'🎉 성장 완료':'🌷 쑥쑥 성장 중')+'</span></div><div class="block-heading"><strong>💖 우리 친구 능력치</strong><span>모두 300이면 엔딩!</span></div><div class="stats">'+stats+'</div><div class="block-heading"><strong>오늘은 뭘 할까?</strong><span>돌볼수록 무럭무럭 자라요</span></div><div class="actions">'+care+'</div><p class="footnote">모든 진행 상황은 기기에 자동 저장됩니다 ✨</p>';
}
function playground(){return '<div class="welcome-chip">⭐ 하루 종일 신나는 놀이터</div><div class="hero-lite"><h2>반짝별 잡기 ⭐</h2><p>20초 동안 떨어지는 별을 터치해 줘!<br>별 하나당 코인 4개가 쌓여.</p><span class="sparkle">🌟</span></div><div class="card game-panel"><div class="game-top"><div><span>남은 시간</span><br><strong id="game-time">'+mini.time+'초</strong></div><div style="text-align:right"><span>잡은 별</span><br><strong id="game-score">'+mini.score+'개</strong></div></div><div class="arena" id="game-arena">'+(!mini.active?'<div class="arena-help">반짝이는 별을 콕콕!<br>⭐ ✨ ⭐</div>':'')+'</div>'+(mini.active?'<button class="btn alt" onclick="finishGame()">그만하고 코인 받기</button>':'<button class="btn" onclick="startGame()">⭐ 별 잡기 시작!</button>')+'<div class="prize">🏆 최고 기록 '+state.best+'개 · 별 하나당 🪙 4코인<br>코인은 상점에서 농장을 꾸밀 때 쓸 수 있어!</div></div>';}
function shop(){return '<div class="welcome-chip">🛍️ 농장 꾸미기 상점</div><h1 class="section-title">우리 농장을 꾸며 보자</h1><p class="sub">별 잡기로 코인을 모아 예쁜 장식을 사 줘!<br>구매한 장식은 농장에 놓거나 치울 수 있어.</p><div class="shop-list">'+SHOP.map(item=>{const owned=state.owned.includes(item.id),on=state.equipped.includes(item.id);return '<div class="card item"><div class="item-art">'+item.emoji+'</div><strong>'+item.name+'</strong><small>'+item.detail+'</small><button class="'+(owned?'owned':'')+'" onclick="shopAction(\''+item.id+'\')">'+(owned?(on?'✓ 배치 중 · 치우기':'다시 배치하기'):'🪙 '+item.cost+' 구매')+'</button></div>';}).join('')+'</div><div class="prize">🌻 구입한 장식은 사라지지 않아! 원하는 만큼 꺼내서 배치해 봐.</div>';}
function book(){return '<div class="welcome-chip">📒 동물 친구 도감</div><h1 class="section-title">우리가 함께한 추억</h1><p class="sub">능력치를 모두 300까지 올리면 엔딩 훈장과 다음 동물이 열려!</p><div class="pet-list">'+SPECIES.map(s=>{const unlocked=state.unlocked.includes(s.id),done=state.finished.includes(s.id);return '<div class="card pet-entry"><div class="pet-avatar">'+(unlocked?animalSvg(s.id):'<span style="font-size:42px">🔒</span>')+'</div><div class="details"><strong>'+s.name+' '+(done?'🏅':'')+'</strong><p>'+(unlocked?('평균 성장 '+avg(s.id)+'/300<br>'+stage(s.id)):'이전 동물의 엔딩을 보면 해금')+'</p></div><button class="'+(unlocked?'':'locked')+'" '+(unlocked?'onclick="selectPet(\''+s.id+'\')"':'disabled')+'>'+(unlocked?(state.current===s.id?'선택 중':'만나기'):'잠김')+'</button></div>';}).join('')+'</div><div class="progress-summary"><strong>🏅 나의 농장 일지</strong><br>현재 계급: '+rank()+'<br>성장 엔딩: '+state.finished.length+' / 3<br>구매한 장식: '+state.owned.length+' / '+SHOP.length+'<br>별 잡기 최고 기록: '+state.best+'개</div>';}
function ending(){if(!modal)return '';const next=modal.next?species(modal.next).name+'도 만날 수 있게 됐어!':'모든 동물과 친구가 되었어!';return '<div class="modal-wrap" role="dialog" aria-modal="true" aria-label="성장 엔딩"><div class="modal"><div class="medal">🏆</div><h2>'+species(modal.id).name+'의 성장 엔딩!</h2><p>정성과 사랑 덕분에 모든 능력치가 300이 됐어.<br><b>축하해! 🪙 150코인 보너스!</b><br>'+next+'</p><button class="btn" onclick="closeModal()">계속 농장 돌보기 🌼</button></div></div>';}
function render(){document.getElementById('root').innerHTML=header()+(state.started?({farm:farm,play:playground,shop:shop,book:book}[tab]||farm)():welcome())+(state.started?nav():'')+ending();}
function toast(message){const el=document.getElementById('toast');clearTimeout(toastTimer);el.textContent=message;el.className='toast';el.hidden=false;toastTimer=setTimeout(()=>{el.hidden=true;},1750);}
function chooseStarter(id){if(state.started||!species(id))return;state.current=id;state.unlocked=[id];state.started=true;save();render();toast(species(id).name+'와 함께 시작! 🌷');}
function selectPet(id){if(!state.unlocked.includes(id))return;state.current=id;tab='farm';save();render();toast(species(id).name+' 등장! 🐾');}
function checkEnding(){if(!allDone(state.current)||state.finished.includes(state.current))return;state.finished.push(state.current);const next=SPECIES.map(x=>x.id).find(id=>!state.unlocked.includes(id))||null;if(next)state.unlocked.push(next);state.coins+=150;modal={id:state.current,next:next};}
function doCare(id){const c=CARE.find(x=>x.id===id);if(!c)return;if(state.coins<c.cost){toast('코인이 부족해! ⭐ 놀이터에서 모아 줘.');return;}state.coins-=c.cost;const p=state.pets[state.current],before=p[c.stat];p[c.stat]=Math.min(300,p[c.stat]+c.gain);checkEnding();save();render();if(!modal)toast((before===300?'이미 최고치야! ':'+')+Math.min(c.gain,300-before)+' '+STATS.find(x=>x.id===c.stat).name+' 💗');}
function petTouch(){const now=Date.now();if(now-lastTap<800)return;lastTap=now;const p=state.pets[state.current],before=p.love;p.love=Math.min(300,p.love+2);checkEnding();save();render();if(!modal)toast(before>=300?'기분이 아주 좋아! 💕':'쓰담쓰담! 애정 +2 💕');}
function shopAction(id){const item=SHOP.find(x=>x.id===id);if(!item)return;if(state.owned.includes(id)){const pos=state.equipped.indexOf(id);if(pos>=0)state.equipped.splice(pos,1);else state.equipped.push(id);save();render();toast(pos>=0?'농장에서 치웠어.':'농장에 배치했어! 🌿');return;}if(state.coins<item.cost){toast('코인이 부족해! ⭐ 별을 잡아 보자.');return;}state.coins-=item.cost;state.owned.push(id);state.equipped.push(id);save();render();toast(item.name+' 구매 완료! 🎁');}
function clearMini(){if(mini.spawnTimer!==null)clearInterval(mini.spawnTimer);if(mini.clockTimer!==null)clearInterval(mini.clockTimer);mini.spawnTimer=null;mini.clockTimer=null;}
function startGame(){if(mini.active)return;mini.active=true;mini.score=0;mini.time=20;render();mini.spawnTimer=setInterval(spawnStar,470);mini.clockTimer=setInterval(()=>{mini.time--;const t=document.getElementById('game-time');if(t)t.textContent=mini.time+'초';if(mini.time<=0)finishGame();},1000);spawnStar();}
function spawnStar(){if(!mini.active)return;const arena=document.getElementById('game-arena');if(!arena)return;const star=document.createElement('button');star.className='falling';star.textContent=Math.random()<.22?'🌟':'⭐';star.setAttribute('aria-label','별 잡기');star.style.left=(4+Math.floor(Math.random()*78))+'%';star.style.animationDuration=(2.3+Math.random()*.65)+'s';star.onclick=()=>{if(!mini.active)return;mini.score++;const el=document.getElementById('game-score');if(el)el.textContent=mini.score+'개';star.remove();};star.addEventListener('animationend',()=>star.remove());arena.appendChild(star);}
function finishGame(){if(!mini.active)return;clearMini();mini.active=false;const reward=mini.score*4;state.coins+=reward;state.best=Math.max(state.best,mini.score);save();render();toast('별 '+mini.score+'개! 🪙 '+reward+'코인 획득!');}
function switchTab(name){if(mini.active)finishGame();tab=name;render();window.scrollTo(0,0);}
function closeModal(){modal=null;render();}
window.gameBack=function(){if(modal){closeModal();return true;}if(tab!=='farm'){switchTab('farm');return true;}return false;};
Object.assign(window,{chooseStarter,selectPet,doCare,petTouch,shopAction,startGame,finishGame,switchTab,closeModal});
render();
})();
