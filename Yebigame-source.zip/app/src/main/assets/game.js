(function () {
'use strict';

// Gameplay stays separate from artwork, so the animal drawings can be replaced later.
const SPECIES = [
  {id:'rabbit', name:'토끼', face:'토끼', hello:'폴짝! 오늘도 신나요!'},
  {id:'cat', name:'고양이', face:'고양이', hello:'냐옹! 같이 놀자!'},
  {id:'penguin', name:'펭귄', face:'펭귄', hello:'오늘은 어디로 갈까?'}
];
const STATS = [
  {id:'love', name:'애정', mark:'♥', color:'#e5869c'},
  {id:'charm', name:'매력', mark:'◆', color:'#deae5e'},
  {id:'brain', name:'지식', mark:'✎', color:'#8badd8'},
  {id:'health', name:'건강', mark:'✚', color:'#78b998'}
];
const ITEMS = [
  {id:'snack',name:'작은 간식',icon:'🍪',stat:'love',gain:5,cost:16,origin:'shop'},
  {id:'ribbon',name:'알록 리본',icon:'🎀',stat:'charm',gain:5,cost:16,origin:'shop'},
  {id:'notebook',name:'작은 공책',icon:'📒',stat:'brain',gain:5,cost:16,origin:'shop'},
  {id:'carrot',name:'싱싱 당근',icon:'🥕',stat:'health',gain:5,cost:16,origin:'shop'},
  {id:'bandage',name:'응급 붕대',icon:'🩹',heal:22,cost:24,origin:'shop'},
  {id:'heartstone',name:'포근한 마음석',icon:'💝',stat:'love',gain:18,origin:'dungeon'},
  {id:'gem',name:'반짝 조약돌',icon:'💎',stat:'charm',gain:18,origin:'dungeon'},
  {id:'scroll',name:'낡은 지혜서',icon:'📜',stat:'brain',gain:18,origin:'dungeon'},
  {id:'herb',name:'힘찬 약초',icon:'🌿',stat:'health',gain:18,origin:'dungeon'},
  {id:'rainbow',name:'무지개 열매',icon:'🍎',stat:'any',gain:26,origin:'dungeon'}
];
const DECOR = [
  {id:'flower',name:'꽃밭',icon:'🌷',cost:0},
  {id:'bench',name:'나무 의자',icon:'🪑',cost:90},
  {id:'lantern',name:'작은 등불',icon:'🏮',cost:105},
  {id:'balloon',name:'풍선',icon:'🎈',cost:125},
  {id:'tree',name:'큰 나무',icon:'🌳',cost:160}
];
const ZONES = [
  {id:'meadow',name:'풀숲 동굴',icon:'🌿',need:0,hp:16,attack:4,coin:14,foes:['심술 두더지','통통 버섯','동굴 지킴이'],loot:['heartstone','herb']},
  {id:'stream',name:'시냇물 유적',icon:'🪨',need:110,hp:30,attack:7,coin:24,foes:['물방울 슬라임','조개 병정','유적 수호자'],loot:['gem','scroll']},
  {id:'forest',name:'깊은 숲',icon:'🌳',need:350,hp:47,attack:11,coin:38,foes:['가시 도치','나뭇잎 정령','숲의 대장'],loot:['scroll','rainbow']}
];
const SAVE_KEY='cozy-animal-farm-v2';
const OLD_KEY='cozy-animal-farm-v1';
const freshStats=()=>({love:0,charm:0,brain:0,health:0});
const clamp=(n,low,high)=>Math.max(low,Math.min(high,Math.floor(Number(n)||0)));
const byId=(arr,id)=>arr.find(x=>x.id===id);
const sample=(arr)=>arr[Math.floor(Math.random()*arr.length)];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function initial(){return {
  version:2,started:false,current:'rabbit',unlocked:[],finished:[],coins:80,
  owned:['flower'],equipped:['flower'],
  pets:{rabbit:freshStats(),cat:freshStats(),penguin:freshStats()},
  bag:{snack:2,ribbon:1,notebook:1,carrot:2,bandage:2},
  dungeon:null,clears:{meadow:0,stream:0,forest:0},totalRuns:0
};}
function load(){
  const out=initial();let src,legacy=false;
  try{src=JSON.parse(localStorage.getItem(SAVE_KEY));}catch(e){}
  if(!src){try{src=JSON.parse(localStorage.getItem(OLD_KEY));legacy=!!src;}catch(e){}}
  if(!src||typeof src!=='object')return out;
  out.started=!!src.started;
  if(byId(SPECIES,src.current))out.current=src.current;
  out.coins=clamp(src.coins,0,100000000);
  for(const key of ['unlocked','finished'])if(Array.isArray(src[key]))out[key]=[...new Set(src[key].filter(id=>!!byId(SPECIES,id)))];
  for(const key of ['owned','equipped'])if(Array.isArray(src[key]))out[key]=[...new Set(src[key].filter(id=>!!byId(DECOR,id)))];
  if(!out.owned.includes('flower'))out.owned.push('flower');
  out.equipped=out.equipped.filter(id=>out.owned.includes(id));
  SPECIES.forEach(s=>STATS.forEach(st=>{out.pets[s.id][st.id]=clamp(src.pets&&src.pets[s.id]&&src.pets[s.id][st.id],0,300);}));
  if(out.started&&!out.unlocked.includes(out.current))out.unlocked.push(out.current);
  if(!legacy){
    if(src.bag&&typeof src.bag==='object'){
      out.bag={};ITEMS.forEach(i=>out.bag[i.id]=clamp(src.bag[i.id],0,999));
    }
    if(src.clears&&typeof src.clears==='object')ZONES.forEach(z=>out.clears[z.id]=clamp(src.clears[z.id],0,999999));
    out.totalRuns=clamp(src.totalRuns,0,999999);
    const d=src.dungeon;
    if(d&&byId(ZONES,d.zone)&&d.room>=1&&d.room<=3){
      out.dungeon={zone:d.zone,room:clamp(d.room,1,3),hp:clamp(d.hp,1,999),maxHp:clamp(d.maxHp,1,999),enemyHp:clamp(d.enemyHp,1,999),earned:clamp(d.earned,0,100000),found:Array.isArray(d.found)?d.found.filter(id=>!!byId(ITEMS,id)).slice(0,15):[],log:typeof d.log==='string'?d.log.slice(0,150):'탐험을 이어가자!',pet:byId(SPECIES,d.pet)?d.pet:out.current};
    }
  }
  return out;
}
const state=load();
let tab='farm',modal=null,toastTimer=null;
function save(){try{localStorage.setItem(SAVE_KEY,JSON.stringify(state));}catch(e){}}
const petStats=id=>state.pets[id];
const avg=id=>Math.floor(STATS.reduce((sum,s)=>sum+petStats(id)[s.id],0)/STATS.length);
const total=id=>STATS.reduce((sum,s)=>sum+petStats(id)[s.id],0);
const allDone=id=>STATS.every(s=>petStats(id)[s.id]>=300);
const tier=id=>avg(id)>=210?2:avg(id)>=95?1:0;
const stage=id=>['기본동물','1차성장','2차성장'][tier(id)];
const rank=()=>['새싹 농부','다정한 사육사','행복한 농장주','전설의 친구'][Math.min(3,state.finished.length)];
const count=id=>state.bag[id]||0;
const statName=id=>(byId(STATS,id)||{}).name||'';

// Temporary simple, flat-color SVG placeholders. Dedicated character art comes after gameplay.
function animalSvg(id){
  const t=tier(id);
  const palette={rabbit:{a:'#fbf1e2',b:'#ef96ad',c:'#ffe1a4'},cat:{a:'#a48bcb',b:'#e5c7ec',c:'#f5d58c'},penguin:{a:'#4f657d',b:'#f7f2e8',c:'#ffc36d'}}[id]||{a:'#fafafa',b:'#aaa',c:'#ddd'};
  const o='#423845',stroke=' stroke="'+o+'" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" ';
  let ears='',tail='',face='',body='',special='';
  if(id==='rabbit'){
    ears='<ellipse cx="76" cy="54" rx="17" ry="49" transform="rotate(-13 76 54)" fill="'+palette.a+'" '+stroke+'/>'+'<ellipse cx="158" cy="54" rx="17" ry="49" transform="rotate(13 158 54)" fill="'+palette.a+'" '+stroke+'/>'+'<ellipse cx="76" cy="53" rx="6" ry="32" transform="rotate(-13 76 53)" fill="'+palette.b+'"/><ellipse cx="158" cy="53" rx="6" ry="32" transform="rotate(13 158 53)" fill="'+palette.b+'"/>';
    body='<ellipse cx="118" cy="182" rx="64" ry="45" fill="'+palette.a+'" '+stroke+'/>';
    face='<circle cx="118" cy="123" r="67" fill="'+palette.a+'" '+stroke+'/><path d="M109 140L127 140L118 150Z" fill="'+palette.b+'"/><path d="M118 151q-9 12-18 0m18 0q9 12 18 0" fill="none" stroke="'+o+'" stroke-width="3"/>';
  }else if(id==='cat'){
    tail='<path d="M170 195Q221 199 198 145" stroke="'+o+'" stroke-width="26" fill="none" stroke-linecap="round"/><path d="M170 195Q221 199 198 145" stroke="'+palette.a+'" stroke-width="18" fill="none" stroke-linecap="round"/>';
    body='<ellipse cx="120" cy="183" rx="62" ry="49" fill="'+palette.a+'" '+stroke+'/>';
    face='<path d="M56 109L60 42L98 65Q120 59 142 65L180 42L183 109Q197 173 119 181Q45 173 56 109Z" fill="'+palette.a+'" '+stroke+'/><path d="M69 57L81 77 69 90ZM170 57L157 77 170 90Z" fill="'+palette.b+'"/><path d="M113 141l13 0-7 8z" fill="'+palette.b+'"/><path d="M119 149q-8 9-16 0m16 0q8 9 16 0" fill="none" stroke="'+o+'" stroke-width="3"/>';
  }else{
    tail='';body='<ellipse cx="118" cy="151" rx="70" ry="79" fill="'+palette.a+'" '+stroke+'/><ellipse cx="118" cy="159" rx="44" ry="59" fill="'+palette.b+'"/><path d="M57 170L41 200m139-30 16 30" stroke="'+o+'" stroke-width="13" stroke-linecap="round"/>';
    face='<ellipse cx="118" cy="95" rx="60" ry="66" fill="'+palette.a+'" '+stroke+'/><ellipse cx="97" cy="107" rx="23" ry="39" fill="'+palette.b+'"/><ellipse cx="139" cy="107" rx="23" ry="39" fill="'+palette.b+'"/><path d="M104 139Q118 129 132 139L118 154Z" fill="'+palette.c+'" '+stroke+'/>';
  }
  if(t>=1){special+='<path d="M83 170Q118 190 153 170L142 194Q118 204 95 194Z" fill="'+palette.b+'" '+stroke+'/><circle cx="118" cy="187" r="8" fill="'+palette.c+'" '+stroke+'/>';}
  if(t>=2){special+='<path d="M103 64L106 36L119 49L135 31L140 60Z" fill="'+palette.c+'" '+stroke+'/>'+'<path d="M62 160Q11 114 24 89Q44 105 68 118M174 160Q226 114 212 89Q192 105 169 118" fill="'+palette.b+'" '+stroke+'/>';}
  const eyes='<ellipse cx="94" cy="125" rx="6" ry="8" fill="'+o+'"/><ellipse cx="143" cy="125" rx="6" ry="8" fill="'+o+'"/>';
  const feet='<ellipse cx="91" cy="219" rx="18" ry="10" fill="'+palette.c+'" '+stroke+'/><ellipse cx="147" cy="219" rx="18" ry="10" fill="'+palette.c+'" '+stroke+'/>';
  return '<svg viewBox="0 0 240 240" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="'+esc(byId(SPECIES,id).name+' '+stage(id))+'">'+tail+body+feet+ears+face+eyes+special+'</svg>';
}
function header(){return '<header class="topbar"><div class="brand"><div class="logo">🐾</div><div><small>ANIMAL FARM</small><strong>포근동물농장</strong></div></div><div class="wallet">🪙 '+state.coins.toLocaleString('ko-KR')+'</div></header>';}
function nav(){return '<nav class="nav" aria-label="게임 메뉴">'+[['farm','🏡','농장'],['dungeon','⚔️','던전'],['bag','🎒','가방'],['shop','🏪','상점'],['book','📒','도감']].map(x=>'<button type="button" class="'+(tab===x[0]?'active':'')+'" onclick="switchTab(\''+x[0]+'\')"><b>'+x[1]+'</b>'+x[2]+'</button>').join('')+'</nav>';}
function welcome(){return '<div class="intro"><div class="chip">처음 만나는 작은 친구</div><h1>포근동물농장</h1><p>아이템을 모아 동물을 키우고,<br>던전을 탐험하며 함께 성장하자!</p><div class="section-head">첫 번째 친구 선택</div><div class="starter-list">'+SPECIES.map(s=>'<button class="card starter" onclick="chooseStarter(\''+s.id+'\')">'+animalSvg(s.id)+'<strong>'+s.name+'</strong><small>이 친구와 시작하기</small></button>').join('')+'</div><p class="footnote">진행 상황은 휴대폰에 자동 저장돼.</p></div>';}
function statsPanel(id){return '<div class="stats">'+STATS.map(s=>'<div class="stat card"><div class="stat-head"><strong>'+s.mark+' '+s.name+'</strong><span>'+petStats(id)[s.id]+'/300</span></div><div class="meter"><div style="width:'+(petStats(id)[s.id]/3)+'%;background:'+s.color+'"></div></div></div>').join('')+'</div>';}
function farm(){
  const id=state.current,s=byId(SPECIES,id);
  const decor=state.equipped.map(id=>byId(DECOR,id)).filter(Boolean).map(d=>'<span class="deco '+d.id+'">'+d.icon+'</span>').join('');
  return '<div class="chip">'+rank()+' · 성장 엔딩 '+state.finished.length+'/3</div><h1>오늘의 농장</h1><p class="sub">'+s.name+'와 함께하는 평화로운 하루</p><div class="sky"><div class="sun"></div><div class="cloud"></div><div class="grassline"></div>'+decor+'<div class="bubble" id="pet-message">'+s.hello+'</div><button type="button" class="pet" aria-label="'+s.name+'에게 인사하기" onclick="petTouch()">'+animalSvg(id)+'</button><span class="stage-chip">'+stage(id)+'</span></div><div class="identity"><div><strong>'+s.name+'</strong><small>평균 능력치 '+avg(id)+' / 300</small></div><div class="flag">'+(allDone(id)?'성장 완료':'성장 중')+'</div></div><div class="section-head">능력치 <span>아이템을 사용해 올려 줘</span></div>'+statsPanel(id)+'<div class="tip"><strong>돈만 써서는 성장할 수 없어!</strong><br>던전에서 아이템을 얻거나 상점에서 작은 육성 아이템을 구입해 가방에서 사용해.</div><div class="two-buttons"><button class="btn" onclick="switchTab(\'bag\')">🎒 가방에서 아이템 사용</button><button class="btn pale" onclick="switchTab(\'dungeon\')">⚔️ 던전 탐험</button></div>';
}
function itemDetail(item){if(item.heal)return '던전 체력 +'+item.heal;if(item.stat==='any')return '선택 능력치 +'+item.gain;return statName(item.stat)+' +'+item.gain;}
function inventory(){
  return '<div class="chip">쓸수록 강해지는 동물</div><h1>내 가방</h1><p class="sub">동전이 아니라 <strong>아이템 사용</strong>으로 능력치가 올라가!</p><div class="tip">육성 대상: <strong>'+byId(SPECIES,state.current).name+'</strong> · '+stage(state.current)+'<br>상점 아이템 +5 / 던전 아이템 +18~26</div><div class="section-head">육성 아이템</div><div class="inventory">'+ITEMS.map(item=>{
    const n=count(item.id),can=item.stat&&n>0;
    return '<div class="card inventory-item"><div class="item-icon">'+item.icon+'</div><div class="item-copy"><strong>'+item.name+'</strong><small>'+itemDetail(item)+' · '+(item.origin==='shop'?'상점':'던전')+'</small><b>보유 '+n+'개</b></div><button type="button" '+(!can?'disabled':'onclick="useItem(\''+item.id+'\')"')+'>'+(!item.stat?'전투용':n?'사용':'없음')+'</button></div>';
  }).join('')+'</div><p class="footnote">전투용 붕대는 던전 화면에서만 사용할 수 있어.</p>';
}
function shop(){
  return '<div class="chip">적은 성장, 확실한 준비</div><h1>마을 상점</h1><p class="sub">상점 아이템은 능력치가 조금만 올라가. 강력한 아이템은 던전에서 찾아봐!</p><div class="section-head">아이템 구매 <span>구매해도 즉시 사용되지는 않아</span></div><div class="inventory">'+ITEMS.filter(i=>i.cost).map(i=>'<div class="card inventory-item"><div class="item-icon">'+i.icon+'</div><div class="item-copy"><strong>'+i.name+'</strong><small>'+itemDetail(i)+'</small><b>보유 '+count(i.id)+'개</b></div><button type="button" onclick="buyItem(\''+i.id+'\')">🪙 '+i.cost+'</button></div>').join('')+'</div><div class="section-head">농장 장식</div><div class="decor-grid">'+DECOR.map(d=>{const owned=state.owned.includes(d.id),equipped=state.equipped.includes(d.id);return '<div class="card decor-item"><span>'+d.icon+'</span><strong>'+d.name+'</strong><button type="button" onclick="buyDecor(\''+d.id+'\')">'+(owned?(equipped?'치우기':'배치하기'):'🪙 '+d.cost)+'</button></div>';}).join('')+'</div>';
}
function zoneAvailable(z){return total(state.current)>=z.need;}
function maxHp(id){return 48+Math.floor(petStats(id).health/10);}
function attackPower(id){return 9+Math.floor(petStats(id).brain/35)+Math.floor(petStats(id).charm/70);}
function foeHp(z,room){return z.hp+(room-1)*8;}
function foeAttack(z,room){return z.attack+(room-1)*2;}
function dungeon(){
  const run=state.dungeon;
  if(!run){return '<div class="chip">싸워서 돈과 아이템 획득</div><h1>던전 탐험</h1><p class="sub">세 구역을 차례로 돌파하는 턴제 탐험. 지면 보상은 잃지 않고 밖으로 나와.</p><div class="tip">참가 동물 <strong>'+byId(SPECIES,state.current).name+'</strong> · 전투력 '+attackPower(state.current)+' · 체력 '+maxHp(state.current)+'<br>더 어려운 던전은 능력치 합계가 높아야 들어갈 수 있어.</div><div class="zones">'+ZONES.map(z=>{
    const unlocked=zoneAvailable(z);
    return '<div class="card zone"><div class="zone-icon">'+z.icon+'</div><div class="zone-text"><strong>'+z.name+'</strong><small>'+(unlocked?'입장 가능':'능력치 합계 '+z.need+' 필요')+' · 완료 '+state.clears[z.id]+'회</small><small>3번의 전투 · 코인 + 희귀 아이템</small></div><button type="button" '+(unlocked?'onclick="enterDungeon(\''+z.id+'\')"':'disabled')+'>'+(unlocked?'입장':'잠김')+'</button></div>';
  }).join('')+'</div><div class="tip">전투 명령: <b>공격</b> 또는 <b>방어</b>. 체력이 부족하면 붕대를 사용하거나 후퇴해.</div>';}
  const z=byId(ZONES,run.zone);
  return '<div class="chip">'+z.name+' · '+run.room+'/3 구역</div><h1>던전 전투</h1><p class="sub">'+byId(SPECIES,run.pet).name+'가 던전에서 탐험 중이야.</p><div class="card battle"><div class="enemy-icon">'+(['👾','🍄','🦇'][run.room-1])+'</div><strong>'+z.foes[run.room-1]+'</strong><div class="battle-row"><span>적 체력</span><b>'+run.enemyHp+' / '+foeHp(z,run.room)+'</b></div><div class="meter enemy-meter"><div style="width:'+(100*run.enemyHp/foeHp(z,run.room))+'%"></div></div><div class="battle-row"><span>내 체력</span><b>'+run.hp+' / '+run.maxHp+'</b></div><div class="meter hero-meter"><div style="width:'+(100*run.hp/run.maxHp)+'%"></div></div><p class="battle-log" role="status">'+esc(run.log)+'</p><div class="battle-actions"><button type="button" onclick="fight(\'attack\')">⚔️ 공격</button><button type="button" onclick="fight(\'guard\')">🛡️ 방어</button><button type="button" onclick="healBattle()">🩹 붕대 ('+count('bandage')+')</button><button type="button" class="pale" onclick="leaveDungeon()">🚪 후퇴</button></div></div><div class="tip">이번 탐험 획득: 🪙 '+run.earned+' · 아이템 '+run.found.length+'개<br>방어하면 적의 공격을 줄이고 작은 피해를 줄 수 있어.</div>';
}
function book(){return '<div class="chip">친구와 함께 기록하기</div><h1>동물 도감</h1><p class="sub">모든 능력치 300 달성 시 엔딩을 보고 다음 동물이 해금돼.</p><div class="pet-list">'+SPECIES.map(s=>{
  const unlocked=state.unlocked.includes(s.id),done=state.finished.includes(s.id);
  return '<div class="card pet-entry"><div class="pet-avatar">'+(unlocked?animalSvg(s.id):'🔒')+'</div><div class="pet-copy"><strong>'+s.name+(done?' 🏅':'')+'</strong><small>'+(unlocked?stage(s.id)+' · 평균 '+avg(s.id)+'/300':'이전 동물 엔딩으로 해금')+'</small></div><button type="button" '+(!unlocked?'disabled':'onclick="selectPet(\''+s.id+'\')"')+'>'+(unlocked?(s.id===state.current?'선택 중':'만나기'):'잠김')+'</button></div>';
 }).join('')+'</div><div class="tip">농장 계급: '+rank()+'<br>완료한 성장 엔딩: '+state.finished.length+'/3<br>총 던전 도전: '+state.totalRuns+'회</div>';
}
function modalHtml(){
  if(!modal)return '';
  return '<div class="modal-wrap" role="dialog" aria-modal="true"><div class="modal"><div class="medal">🏅</div><h2>'+esc(modal.title)+'</h2><p>'+esc(modal.body)+'</p><button class="btn" onclick="closeModal()">확인</button></div></div>';
}
function render(){
  const body={farm,dungeon,bag:inventory,shop,book};
  document.getElementById('root').innerHTML=header()+(state.started?body[tab]():welcome())+(state.started?nav():'')+modalHtml();
}
function toast(message){
  const el=document.getElementById('toast');clearTimeout(toastTimer);
  el.hidden=false;el.textContent=message;
  toastTimer=setTimeout(()=>{el.hidden=true;},1700);
}
function chooseStarter(id){
  if(state.started||!byId(SPECIES,id))return;
  state.started=true;state.current=id;state.unlocked=[id];save();render();toast(byId(SPECIES,id).name+'와 농장 시작!');
}
function selectPet(id){if(!state.unlocked.includes(id)||state.dungeon)return;state.current=id;tab='farm';save();render();}
function checkEnding(){
  const id=state.current;
  if(!allDone(id)||state.finished.includes(id))return;
  state.finished.push(id);
  const next=SPECIES.find(s=>!state.unlocked.includes(s.id));
  if(next)state.unlocked.push(next.id);
  state.coins+=160;
  modal={title:byId(SPECIES,id).name+' 성장 완료!',body:'모든 능력치 300 달성! 160코인을 받았어. '+(next?next.name+' 친구가 새로 열렸어.':'모든 동물을 성장시켰어!')};
}
function petTouch(){toast(byId(SPECIES,state.current).hello+' (능력치는 아이템으로만 증가)');}
function addItem(id,qty){if(byId(ITEMS,id))state.bag[id]=clamp(count(id)+qty,0,999);}
function useItem(id){
  const it=byId(ITEMS,id);
  if(!it||!it.stat||count(id)<1)return;
  const p=petStats(state.current);
  let target=it.stat;
  if(target==='any')target=STATS.map(s=>s.id).filter(s=>p[s]<300).sort((a,b)=>p[a]-p[b])[0];
  if(!target){toast('모든 능력치가 최고야!');return;}
  const before=p[target];if(before>=300){toast('그 능력치는 이미 300이야!');return;}
  const gain=Math.min(it.gain,300-before);
  p[target]+=gain;state.bag[id]--;checkEnding();save();render();
  if(!modal)toast(it.name+' 사용! '+statName(target)+' +'+gain);
}
function buyItem(id){
  const it=byId(ITEMS,id);if(!it||!it.cost)return;
  if(state.coins<it.cost){toast('코인이 부족해. 던전에서 모아 줘!');return;}
  if(count(id)>=999){toast('가방이 가득 찼어!');return;}
  state.coins-=it.cost;addItem(id,1);save();render();toast(it.name+' 1개 구매!');
}
function buyDecor(id){
  const d=byId(DECOR,id);if(!d)return;
  if(state.owned.includes(id)){
    const idx=state.equipped.indexOf(id);
    if(idx<0)state.equipped.push(id);else state.equipped.splice(idx,1);
  }else{
    if(state.coins<d.cost){toast('코인이 부족해!');return;}
    state.coins-=d.cost;state.owned.push(id);state.equipped.push(id);
  }
  save();render();
}
function enterDungeon(id){
  const z=byId(ZONES,id);
  if(state.dungeon||!z||!zoneAvailable(z))return;
  state.dungeon={zone:id,room:1,hp:maxHp(state.current),maxHp:maxHp(state.current),enemyHp:foeHp(z,1),earned:0,found:[],log:z.foes[0]+' 등장! 어떻게 할까?',pet:state.current};
  state.totalRuns++;save();render();
}
function fight(action){
  const r=state.dungeon;if(!r||!['attack','guard'].includes(action))return;
  const z=byId(ZONES,r.zone);
  const damage=action==='attack'?attackPower(r.pet)+Math.floor(Math.random()*4):3;
  r.enemyHp=Math.max(0,r.enemyHp-damage);
  if(r.enemyHp<=0){winRoom();return;}
  const counter=Math.max(1,foeAttack(z,r.room)+Math.floor(Math.random()*3)-(action==='guard'?Math.ceil(foeAttack(z,r.room)*.8):0));
  r.hp=Math.max(0,r.hp-counter);
  r.log=(action==='guard'?'방어 태세! ':'공격 성공! ')+'적에게 '+damage+' 피해, 반격으로 '+counter+' 피해.';
  if(r.hp<=0){
    const coins=r.earned;
    state.dungeon=null;save();render();
    modal={title:'던전에서 쓰러졌어',body:'돌아왔지만 이번 탐험에서 얻은 코인 '+coins+'과 아이템은 그대로 가지고 있어. 다시 도전하자!'};
    render();return;
  }
  save();render();
}
function winRoom(){
  const r=state.dungeon;if(!r)return;
  const z=byId(ZONES,r.zone),room=r.room;
  const coin=z.coin+(room-1)*7+Math.floor(Math.random()*7);
  const loot=room===3&&Math.random()<.3?'rainbow':sample(z.loot);
  state.coins+=coin;addItem(loot,1);r.earned+=coin;r.found.push(loot);
  if(room===3){
    state.clears[z.id]++;
    const earned=r.earned,found=r.found.map(id=>byId(ITEMS,id).name).join(', ');
    state.dungeon=null;save();
    modal={title:z.name+' 돌파 성공!',body:'코인 '+earned+'개 획득! 획득한 아이템: '+found+'. 가방에서 사용해 동물을 성장시키자.'};
    render();return;
  }
  r.room++;
  r.enemyHp=foeHp(z,r.room);
  r.log='승리! 🪙 '+coin+'과 '+byId(ITEMS,loot).name+' 획득. 다음 적이 등장했어.';
  save();render();
}
function healBattle(){
  const r=state.dungeon;if(!r)return;
  const it=byId(ITEMS,'bandage');
  if(!count('bandage')){toast('붕대가 없어! 상점에서 구입할 수 있어.');return;}
  if(r.hp>=r.maxHp){toast('이미 체력이 가득 차 있어!');return;}
  state.bag.bandage--;
  const recovered=Math.min(it.heal,r.maxHp-r.hp);
  r.hp+=recovered;r.log='붕대로 체력 '+recovered+' 회복! (적의 반격은 없음)';
  save();render();
}
function leaveDungeon(){
  const r=state.dungeon;if(!r)return;
  const earned=r.earned;
  state.dungeon=null;save();render();toast('후퇴했어. 획득한 코인 '+earned+'과 아이템은 유지돼.');
}
function switchTab(id){
  if(!['farm','dungeon','bag','shop','book'].includes(id))return;
  tab=id;render();window.scrollTo(0,0);
}
function closeModal(){modal=null;render();}
window.gameBack=function(){if(modal){closeModal();return true;}if(tab!=='farm'){switchTab('farm');return true;}return false;};
Object.assign(window,{chooseStarter,selectPet,petTouch,useItem,buyItem,buyDecor,enterDungeon,fight,healBattle,leaveDungeon,switchTab,closeModal});
// Test-only hook that is unavailable to external sites because this is a local offline WebView.
window.__farmTest={state,ITEMS,ZONES,STATS,save};
save();render();
})();
