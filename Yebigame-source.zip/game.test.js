const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(__dirname+'/app/src/main/assets/game.js','utf8');
function boot(data={}){
  const store={...data},root={innerHTML:''},toast={textContent:'',hidden:true};
  const localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v;}};
  const window={scrollTo:()=>{}};
  const document={getElementById:id=>({root,toast})[id]||null};
  const stableMath=Object.create(Math);stableMath.random=()=>0.5;
  const context=vm.createContext({window,document,localStorage,Math:stableMath,JSON,Number,setTimeout,clearTimeout});
  vm.runInContext(source,context);
  return {window,root,store,get state(){return window.__farmTest.state}};
}
function test(name,fn){try{fn();console.log('PASS',name)}catch(e){console.error('FAIL',name);throw e}}

test('new farm has inventory and no minigame',()=>{
  const b=boot();assert.equal(b.state.started,false);assert.match(b.root.innerHTML,/첫 번째 친구/);
  b.window.chooseStarter('rabbit');assert.equal(b.state.started,true);
  assert.equal(b.state.bag.snack,2);assert.doesNotMatch(b.root.innerHTML,/반짝별 잡기|별 잡기/);
  b.window.switchTab('dungeon');assert.match(b.root.innerHTML,/던전 탐험/);
});
test('pet tapping and coin spending do not directly increase stats',()=>{
  const b=boot();b.window.chooseStarter('cat');const before=b.state.pets.cat.love;
  b.window.petTouch();assert.equal(b.state.pets.cat.love,before);
  const oldCoins=b.state.coins,oldCount=b.state.bag.snack;
  b.window.buyItem('snack');assert.equal(b.state.coins,oldCoins-16);
  assert.equal(b.state.bag.snack,oldCount+1);assert.equal(b.state.pets.cat.love,before);
  b.window.useItem('snack');assert.equal(b.state.pets.cat.love,before+5);
  assert.equal(b.state.bag.snack,oldCount);
});
test('dungeon gives coins and loot, survives save and reload',()=>{
  const b=boot();b.window.chooseStarter('penguin');
  const coins=b.state.coins;b.window.enterDungeon('meadow');
  assert.equal(b.state.dungeon.room,1);
  let steps=0;
  while(b.state.dungeon&&steps++<100){
    if(b.state.dungeon.hp<20&&b.state.bag.bandage>0)b.window.healBattle();
    b.window.fight('attack');
  }
  assert.ok(steps<100,'dungeon should finish');
  assert.equal(b.state.clears.meadow,1);
  assert.ok(b.state.coins>coins);
  assert.ok((b.state.bag.heartstone||0)+(b.state.bag.herb||0)+(b.state.bag.rainbow||0)>=3);
  const reloaded=boot(b.store);
  assert.equal(reloaded.state.clears.meadow,1);
  assert.equal(reloaded.state.coins,b.state.coins);
});
test('dungeon unlock needs actual pet growth',()=>{
  const b=boot();b.window.chooseStarter('rabbit');
  b.window.enterDungeon('stream');assert.equal(b.state.dungeon,null);
  b.state.pets.rabbit.love=110;
  b.window.enterDungeon('stream');assert.equal(b.state.dungeon.zone,'stream');
});
test('after 4 stats reach 300, end unlocks the next animal',()=>{
  const b=boot();b.window.chooseStarter('rabbit');
  ['love','charm','brain','health'].forEach(id=>b.state.pets.rabbit[id]=299);
  b.state.bag.rainbow=4;
  for(let i=0;i<4;i++)b.window.useItem('rainbow');
  assert.equal(b.state.finished.includes('rabbit'),true);
  assert.equal(b.state.unlocked.includes('cat'),true);
  assert.equal(b.state.pets.rabbit.love,300);
  assert.equal(b.state.pets.rabbit.health,300);
});
test('legacy version one save migrates without losing growth',()=>{
  const old={started:true,current:'penguin',unlocked:['penguin'],coins:219,pets:{penguin:{love:79,charm:44,brain:13,health:2}}};
  const b=boot({'cozy-animal-farm-v1':JSON.stringify(old)});
  assert.equal(b.state.coins,219);
  assert.equal(b.state.current,'penguin');
  assert.equal(b.state.pets.penguin.love,79);
  assert.ok(b.state.bag.snack>0);
  assert.ok(b.store['cozy-animal-farm-v2']);
});
test('store item only adds a small stat boost; dungeon loot is stronger',()=>{
  const b=boot();assert.equal(b.window.__farmTest.ITEMS.find(i=>i.id==='snack').gain,5);
  assert.ok(b.window.__farmTest.ITEMS.find(i=>i.id==='heartstone').gain>5);
});
console.log('All game logic tests passed.');
test('a purchased shop item remains in the bag after reload',()=>{
  const b=boot();b.window.chooseStarter('rabbit');b.window.buyItem('ribbon');
  const before=b.state.bag.ribbon;
  const r=boot(b.store);
  assert.equal(r.state.bag.ribbon,before);
  assert.equal(r.state.pets.rabbit.charm,0);
});
test('dungeon retreat keeps coins and items already won',()=>{
  const b=boot();b.window.chooseStarter('rabbit');
  b.window.enterDungeon('meadow');
  let n=0;
  while(b.state.dungeon&&b.state.dungeon.room===1&&n++<12)b.window.fight('attack');
  assert.ok(b.state.dungeon);
  const got=b.state.coins,stock=(b.state.bag.heartstone||0)+(b.state.bag.herb||0);
  assert.ok(stock>=1);
  b.window.leaveDungeon();
  assert.equal(b.state.dungeon,null);assert.equal(b.state.coins,got);
  assert.equal((b.state.bag.heartstone||0)+(b.state.bag.herb||0),stock);
});
