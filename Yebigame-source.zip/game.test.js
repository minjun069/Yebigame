const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const source=fs.readFileSync(__dirname+'/app/src/main/assets/game.js','utf8');
function boot(data={}) {
 const store={...data},root={innerHTML:''},toast={textContent:'',hidden:true};
 const handlers={};
 const localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v;}};
 const window={scrollTo:()=>{}};
 const document={getElementById:k=>({root,toast})[k]||null,addEventListener:(k,fn)=>handlers[k]=fn};
 const stableMath=Object.create(Math);stableMath.random=()=>0.5;
 const context=vm.createContext({window,document,localStorage,Math:stableMath,JSON,Number,setTimeout:()=>1,clearTimeout:()=>{}});
 vm.runInContext(source,context);
 const api=window.__retroGame;
 return {api,store,root,click:(a,id)=>{const el={disabled:false,dataset:{a,id}};handlers.click({target:{closest:()=>el}});}};
}
let passed=0;
function test(label,fn){try{fn();console.log('PASS',label);passed++}catch(err){console.error('FAIL',label);throw err}}
test('new farm supports choosing rabbit, cat, penguin',()=>{const b=boot();assert.match(b.root.innerHTML,/첫 번째 친구/);b.api.chooseStarter('cat');assert.equal(b.api.state.current,'cat');assert.equal(b.api.state.started,true);assert.match(b.root.innerHTML,/nav_farm_active/);});
test('shopping does not raise stats until item used',()=>{const b=boot();b.api.chooseStarter('rabbit');const old=b.api.state.coins,n=b.api.state.bag.snack;b.api.buyItem('snack');assert.equal(b.api.state.coins,old-16);assert.equal(b.api.state.bag.snack,n+1);assert.equal(b.api.state.pets.rabbit.love,0);b.api.useItem('snack');assert.equal(b.api.state.pets.rabbit.love,5);assert.equal(b.api.state.bag.snack,n);});
test('no minigame and dungeon rewards persist after reload',()=>{const b=boot();b.api.chooseStarter('penguin');b.api.enterDungeon('meadow');let steps=0;while(b.api.state.dungeon&&steps++<100){if(b.api.state.dungeon.hp<20&&b.api.state.bag.bandage>0)b.api.healBattle();b.api.fight('attack');}assert.ok(steps<100);assert.equal(b.api.state.clears.meadow,1);assert.ok(b.api.state.coins>80);let re=boot(b.store);assert.equal(re.api.state.clears.meadow,1);assert.equal(re.api.state.coins,b.api.state.coins);assert.doesNotMatch(re.root.innerHTML,/미니게임/);});
test('dungeon entry requires enough stats',()=>{const b=boot();b.api.chooseStarter('rabbit');b.api.enterDungeon('stream');assert.equal(b.api.state.dungeon,null);b.api.state.pets.rabbit.love=110;b.api.enterDungeon('stream');assert.equal(b.api.state.dungeon.zone,'stream');});
test('retreat keeps coins and loot',()=>{const b=boot();b.api.chooseStarter('rabbit');b.api.enterDungeon('meadow');let n=0;while(b.api.state.dungeon&&b.api.state.dungeon.room===1&&n++<20)b.api.fight('attack');const coins=b.api.state.coins,loot=b.api.state.bag.herb+b.api.state.bag.heartstone;b.api.leaveDungeon();assert.equal(b.api.state.dungeon,null);assert.equal(b.api.state.coins,coins);assert.equal(b.api.state.bag.herb+b.api.state.bag.heartstone,loot);});
test('all 4 stats at 300 unlock next animal',()=>{const b=boot();b.api.chooseStarter('rabbit');const s=b.api.state.pets.rabbit;for(const id of ['love','charm','brain','health'])s[id]=299;b.api.state.bag.rainbow=4;for(const id of ['love','charm','brain','health'])b.click('rainbow',id);assert.ok(b.api.state.finished.includes('rabbit'));assert.ok(b.api.state.unlocked.includes('cat'));assert.equal(s.love,300);assert.equal(s.health,300);});
test('legacy v1 save migrates without losing stats',()=>{const old={started:true,current:'penguin',unlocked:['penguin'],coins:219,pets:{penguin:{love:79,charm:44,brain:13,health:2}}};const b=boot({'cozy-animal-farm-v1':JSON.stringify(old)});assert.equal(b.api.state.coins,219);assert.equal(b.api.state.pets.penguin.love,79);assert.ok(b.api.state.bag.snack>0);assert.ok(b.store['cozy-animal-farm-v2']);});
test('saved v2 inventory survives reload',()=>{const b=boot();b.api.chooseStarter('rabbit');b.api.buyItem('ribbon');const n=b.api.state.bag.ribbon;const re=boot(b.store);assert.equal(re.api.state.bag.ribbon,n);});
test('assets exist for all animals, items and dungeon foes',()=>{const base=__dirname+'/app/src/main/assets/art/';for(const s of ['rabbit','cat','penguin'])for(let i=0;i<3;i++)assert.ok(fs.existsSync(base+s+'_'+i+'.png'));for(const i of ['snack','ribbon','notebook','carrot','bandage','heartstone','gem','scroll','herb','rainbow'])assert.ok(fs.existsSync(base+i+'.png'));for(const n of ['mole','slime','guardian','shell_soldier','hedgehog','forest_boss'])assert.ok(fs.existsSync(base+n+'.png'));});
console.log('All '+passed+' tests passed.');

require('./asset-audit.js');
