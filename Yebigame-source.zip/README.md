# 포근동물농장 🐾

주니어네이버의 추억을 참고해 독자적으로 만든 오프라인 Android 동물 육성 게임입니다.

## 게임 기능

- 토끼, 고양이, 펭귄 중 한 마리로 시작
- 애정·매력·지식·건강을 각각 300까지 올리면 엔딩
- 엔딩 보상으로 다음 동물 해금
- 20초 별 잡기 미니게임, 코인 획득
- 상점에서 장식 구매 및 농장 꾸미기
- 기기 내부 자동 저장

## APK 설치 (휴대폰)

1. [GitHub Actions](../../actions/workflows/build-apk.yml) 열기
2. 가장 최근에 성공한 **Build Android APK** 실행 선택
3. 맨 아래 **Artifacts**의 **Yebigame-debug-apk** 다운로드
4. ZIP 압축 해제 후 `app-debug.apk` 설치

## 개발 환경

- Java + Android WebView + HTML/CSS/JavaScript, 오프라인 동작
- Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK 35, Java 17
- Android Studio나 PC 없이 GitHub Actions로 APK 빌드

원작의 이미지, 음악, 소스코드 등은 사용하지 않은 비공식 개인 창작물입니다.
