'use strict';
const fs=require('node:fs');const assert=require('node:assert/strict');const path=require('node:path');
const root=path.join(__dirname,'app','src','main','assets','art');
const actual=fs.readdirSync(root).filter(x=>x.endsWith('.png')).sort();
const expected=['logo_title','farm_scene','barn','windmill','apple_tree','hay','carrot_crate','fence','bush','flowers','mushrooms','stump','grass','clouds','bench','lantern','balloon','coin','gem','snack','ribbon','notebook','carrot','bandage','heartstone','pebble','scroll','herb','rainbow','mole','mushroom_enemy','guardian','slime','slime_jump','shell_soldier','relic_golem','hedgehog','leaf_spirit','forest_boss','forest_boss_attack'];
for(const s of ['rabbit','cat','penguin'])for(const suffix of ['0','1','2','happy','sleep','surprise','idle_a','idle_b'])expected.push(s+'_'+suffix);
for(const tab of ['farm','dungeon','bag','shop','book'])for(const suffix of ['', '_active'])expected.push('nav_'+tab+suffix);
assert.equal(expected.length,74);
assert.deepEqual(actual,expected.map(x=>x+'.png').sort(),'Unexpected, duplicate or missing asset file');
const seenHashes=new Map();const crypto=require('node:crypto');
for(const name of actual){
 const bytes=fs.readFileSync(path.join(root,name));
 assert.ok(bytes.length>1500,name+' suspiciously small');
 assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a',name+' bad PNG signature');
 const w=bytes.readUInt32BE(16),h=bytes.readUInt32BE(20);
 assert.ok(w>40&&h>40&&w<=1400&&h<=1400,name+' invalid dimensions '+w+'x'+h);
 assert.equal(bytes[25],6,name+' must be RGBA color type 6');
 const hash=crypto.createHash('sha256').update(bytes).digest('hex');
 assert.ok(!seenHashes.has(hash),name+' duplicates '+seenHashes.get(hash));
 seenHashes.set(hash,name);
}
console.log('PASS: '+actual.length+' distinct RGBA PNG assets, dimensions and file signatures checked.');
